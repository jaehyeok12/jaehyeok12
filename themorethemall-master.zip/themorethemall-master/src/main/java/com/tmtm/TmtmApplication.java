package com.tmtm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TmtmApplication {

	public static void main(String[] args) {
		SpringApplication.run(TmtmApplication.class, args);
	}

}
