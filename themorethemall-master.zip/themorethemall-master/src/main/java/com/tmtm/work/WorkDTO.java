package com.tmtm.work;

public class WorkDTO {

}
